Fashion E-Retail — Course Project (ICT602)
Module implemented: Order Processing with Payment Orchestration (Java)
Group: 17
## How to run
Build and run (requires JDK 17 and Maven):
