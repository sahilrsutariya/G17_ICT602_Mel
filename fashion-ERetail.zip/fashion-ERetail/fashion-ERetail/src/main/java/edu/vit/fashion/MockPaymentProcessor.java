package edu.vit.fashion;
public class MockPaymentProcessor implements PaymentProcessor {
    @Override
    public boolean processPayment(Order order) {
        System.out.println("[Payment] Processing payment for order " + order.getId() + " amount=" + order.getAmount());
        try { Thread.sleep(500); } catch (InterruptedException e) { /* ignore */ }
        System.out.println("[Payment] Payment succeeded for order " + order.getId());
        return true;
    }
}
