package edu.vit.fashion;
public class OrderService {
    private final PaymentProcessor paymentProcessor;
    public OrderService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    public boolean processOrder(Order order) {
        System.out.println("[OrderService] Starting processing: " + order);
        boolean paid = paymentProcessor.processPayment(order);
        if (paid) {
            order.setStatus("PAID");
            System.out.println("[OrderService] Order completed: " + order);
            return true;
        } else {
            order.setStatus("PAYMENT_FAILED");
            System.out.println("[OrderService] Payment failed for: " + order);
            return false;
        }
    }
}
