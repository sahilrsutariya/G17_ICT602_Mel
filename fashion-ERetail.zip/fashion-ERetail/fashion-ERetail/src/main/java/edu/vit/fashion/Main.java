package edu.vit.fashion;
public class Main {
    public static void main(String[] args) {
        System.out.println("=== Order Processing Demo ===");
        OrderService service = new OrderService(new MockPaymentProcessor());
        Order o1 = new Order("ORD-1001", 79.99);
        Order o2 = new Order("ORD-1002", 159.50);
        service.processOrder(o1);
        service.processOrder(o2);
        System.out.println("=== Demo finished ===");
    }
}
