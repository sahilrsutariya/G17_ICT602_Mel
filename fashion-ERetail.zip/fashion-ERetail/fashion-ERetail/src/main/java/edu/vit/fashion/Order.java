package edu.vit.fashion;
public class Order {
    private final String id;
    private final double amount;
    private String status;
    public Order(String id, double amount) {
        this.id = id;
        this.amount = amount;
        this.status = "CREATED";
    }
    public String getId() { return id; }
    public double getAmount() { return amount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    @Override
    public String toString() {
        return "Order{id='" + id + "', amount=" + amount + ", status='" + status + "'}";
    }
}
