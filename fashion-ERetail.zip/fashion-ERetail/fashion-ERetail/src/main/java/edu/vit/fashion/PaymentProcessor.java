package edu.vit.fashion;
public interface PaymentProcessor {
    boolean processPayment(Order order);
}
