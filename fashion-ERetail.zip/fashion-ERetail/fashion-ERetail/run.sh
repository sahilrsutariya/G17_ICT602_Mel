#!/bin/bash
mvn -q package
java -cp target/fashion-ERetail-1.0-SNAPSHOT.jar edu.vit.fashion.Main
